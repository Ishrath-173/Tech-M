package com.aits.Spring_IOC;

public class PropertyTax implements Tax{

	@Override
	public void setTaxableAmount(double amount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calculateTaxAmount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double getTaxAmount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getTaxType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isTaxPayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void PayTax() {
		// TODO Auto-generated method stub
		
	}

}
