package com.aits.Spring_IOC;

public interface PaymentProcessor {
	void doPayment();

}
