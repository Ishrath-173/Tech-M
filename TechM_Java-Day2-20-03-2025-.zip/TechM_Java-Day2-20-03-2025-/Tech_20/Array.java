package Tech_21;

import java.util.Arrays;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[]= {1,8,7,4,6,3};
		int n=arr.length;
		Arrays.sort(arr);
		System.out.println(arr[n-1]);
		
		
	}

}
