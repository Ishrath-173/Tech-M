package com.aits.Springdemo;

public interface TransportService {
	
	void BookTicket(String source, String destination);

}
